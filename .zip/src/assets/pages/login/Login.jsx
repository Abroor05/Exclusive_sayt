import React from 'react'

function Login() {
  return (
    <>
        salom
        
    </>
  )
}

export default Login