import React from 'react'

function Aboute() {
  return (
    <>

        salom

    </>
  )
}

export default Aboute